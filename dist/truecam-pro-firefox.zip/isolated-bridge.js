/**
 * TrueCam Pro - Firefox Isolated World Bridge
 * In Firefox MV3, content_scripts do not support "world": "MAIN".
 * This bridge injects main-injector.js directly into the webpage DOM at document_start
 * and synchronizes user preferences between browser.storage and the page context.
 */
(function () {
  'use strict';

  // 1. DYNAMIC MAIN-WORLD INJECTION FOR FIREFOX MV3
  function injectMainScript() {
    try {
      const getURL = (typeof browser !== 'undefined' && browser.runtime?.getURL)
        ? browser.runtime.getURL.bind(browser.runtime)
        : (typeof chrome !== 'undefined' && chrome.runtime?.getURL ? chrome.runtime.getURL.bind(chrome.runtime) : null);

      if (!getURL) return;

      const scriptUrl = getURL('main-injector.js');
      const script = document.createElement('script');
      script.src = scriptUrl;
      script.async = false;

      const target = document.head || document.documentElement;
      if (target) {
        target.appendChild(script);
        script.remove();
      } else {
        document.addEventListener('DOMContentLoaded', () => {
          const docTarget = document.head || document.documentElement;
          if (docTarget) {
            docTarget.appendChild(script);
            script.remove();
          }
        }, { once: true });
      }
    } catch (err) {
      console.warn('[TrueCam Bridge] Firefox injection error:', err);
    }
  }

  injectMainScript();

  // 2. CONFIGURATION SYNC
  const DEFAULT_CONFIG = {
    mirrorEnabled: true,
    flipHorizontal: true,
    flipVertical: false,
    rotation: 0
  };

  const storageApi = (typeof browser !== 'undefined' && browser.storage)
    ? browser.storage
    : (typeof chrome !== 'undefined' && chrome.storage ? chrome.storage : null);

  function broadcastConfig(config) {
    try {
      window.sessionStorage.setItem('__TRUECAM_CONFIG__', JSON.stringify(config));
    } catch (e) {}
    window.postMessage(
      {
        source: 'TRUECAM_EXTENSION',
        type: 'TRUECAM_CONFIG_UPDATE',
        config: config
      },
      '*'
    );
  }

  function loadAndBroadcast() {
    if (!storageApi || !storageApi.local) return;
    try {
      storageApi.local.get(
        ['mirrorEnabled', 'flipHorizontal', 'flipVertical', 'rotation'],
        (result) => {
          const err = (typeof chrome !== 'undefined' && chrome.runtime?.lastError);
          if (err) {
            console.warn('[TrueCam Bridge] Storage read error:', err);
            return;
          }
          const res = result || {};
          const config = {
            mirrorEnabled: res.mirrorEnabled !== undefined ? res.mirrorEnabled : DEFAULT_CONFIG.mirrorEnabled,
            flipHorizontal: res.flipHorizontal !== undefined ? res.flipHorizontal : DEFAULT_CONFIG.flipHorizontal,
            flipVertical: res.flipVertical !== undefined ? res.flipVertical : DEFAULT_CONFIG.flipVertical,
            rotation: res.rotation !== undefined ? res.rotation : DEFAULT_CONFIG.rotation
          };
          broadcastConfig(config);
        }
      );
    } catch (e) {
      console.warn('[TrueCam Bridge] Context error:', e);
    }
  }

  if (storageApi && storageApi.onChanged) {
    storageApi.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local') {
        loadAndBroadcast();
      }
    });
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return;
    if (event.data.source === 'TRUECAM_MAIN' && event.data.type === 'TRUECAM_REQUEST_CONFIG') {
      loadAndBroadcast();
    }
  });

  loadAndBroadcast();
})();
